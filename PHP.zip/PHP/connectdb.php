<?php
	$db=mysqli_connect("sql109.byethost15.com","b15_16202987","jN5ChOpg6H", "b15_16202987_DB");
?>

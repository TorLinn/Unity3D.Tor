<?php
include_once 'connectdb.php';
mysql_query("TRUNCATE TABLE `kubik_poss`");
?>

<?php
    include_once 'connectdb.php'; 
    if (isset($_POST['login']) && isset($_POST['pass'])) {
        $login = mysqli_real_escape_string($db, $_POST['login']);
        $pass = mysqli_real_escape_string($db, $_POST['pass']);
        $result = mysqli_query($db, "SELECT * FROM `Towers3D` WHERE `login` = '$login' and `pass` = '$pass';");
        $numRows = mysqli_num_rows($result);
        mysqli_free_result($result);
        if ($numRows > 0) {
            exit('Ok');
        } else {
            exit ('Not Ok');
        }
    } else {
        exit ('Error. Login and Password required.');
    }
?>


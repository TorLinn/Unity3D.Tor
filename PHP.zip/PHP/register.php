<?php
    include_once 'connectdb.php';
    if (isset($_POST['login']) && isset($_POST['pass']) && isset($_POST['email'])) {
        $login = mysqli_real_escape_string($db, $_POST['login']);
        $pass = mysqli_real_escape_string($db, $_POST['pass']);
        $email = mysqli_real_escape_string($db, $_POST['email']);
        $result = mysqli_query($db, "SELECT * FROM `Towers3D` WHERE `login` = '$login';");
        $numRows = mysqli_num_rows($result);
        mysqli_free_result($result);
        if ($numRows == 0) {
            if (mysqli_query($db, "INSERT INTO `Towers3D`(`login`, `pass`, `email`, `isactiv`) VALUES ('$login', '$pass', '$email', 1);")) {
                exit('Ok');
            } else {
                exit ('Unknown error.');
            }
        } else {
            exit('Error. Login already exists.');
        }
    } else {
        exit('Error. Login and Password required.');
    }
?>
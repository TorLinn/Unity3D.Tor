<?php
include_once 'connectdb.php';

    $result = mysql_query("SELECT `name`,`x`, `y`, `z`, `rx`, `ry`, `rz`, `rw` FROM `kubik_poss`");
    while(($row=mysql_fetch_array($result))){
        $rows[]=$row;
    }
    echo json_encode($rows);

?>

<?php
$db=mysqli_connect("mysql.hostinger.com.ua","u353660657_root","4qUqymh3bv", "u353660657_unidb");
mysqli_query($db, "SET NAMES utf8");
?>